<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {

    public function index(){
        $this->load->model('dosen_model', "dsn1");

        $this->dsn1->nama = $this->input->post('nama');
        $this->dsn1->pendidikan = $this->input->post('pendidikan');
        $this->dsn1->prodi = $this->input->post('prodi');

        $data['dsn1']=$this->dsn1;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/index', $data);
        $this->load->view('layout/footer');
    }


}