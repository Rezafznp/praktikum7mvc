<?php echo form_open('dosen/index')?>
  <div class="form-group row">
    <label for="nama" class="col-4 col-form-label">Nama Dosen</label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-address-card"></i>
          </div>
        </div> 
        <input id="nama" name="nama" type="text" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="pendidikan" class="col-4 col-form-label">Pendidikan</label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-angle-double-down"></i>
          </div>
        </div> 
        <input id="pendidikan" name="pendidikan" type="text" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label class="col-4">Prodi</label> 
    <div class="col-8">
      <div class="custom-control custom-radio custom-control-inline">
        <input name="prodi" id="prodi_0" type="radio" class="custom-control-input" value="SI"> 
        <label for="prodi_0" class="custom-control-label">Sistem Informasi</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="prodi" id="prodi_1" type="radio" class="custom-control-input" value="TI"> 
        <label for="prodi_1" class="custom-control-label">Teknik Informatika</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="prodi" id="prodi_2" type="radio" class="custom-control-input" value="BD"> 
        <label for="prodi_2" class="custom-control-label">Bisnis Digital</label>
      </div>
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
  <?php echo form_close(); ?>
