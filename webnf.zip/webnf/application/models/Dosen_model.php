<?php

class Dosen_model extends CI_Model {
    public $nidn,
           $pendidikan,
           $prodi,
           $nama;

}